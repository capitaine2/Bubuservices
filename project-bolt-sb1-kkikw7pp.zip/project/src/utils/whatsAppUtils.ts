// WhatsApp phone number without any special characters
const WHATSAPP_PHONE = '221787244168';

/**
 * Generates a WhatsApp URL for order placement that works whether WhatsApp is open or closed
 * Uses the universal wa.me format that works across all platforms
 */
export function generateWhatsAppOrderUrl(items: Array<{ product: { name: string; price: number }; quantity: number }>, totalPrice: number): string {
  const itemsList = items
    .map(item => `- ${item.product.name} (${item.quantity}x) : ${item.product.price.toLocaleString('fr-FR')} FCFA`)
    .join('\n');
    
  const message = `Bonjour, je souhaite commander :\n\n${itemsList}\n\nTotal : ${totalPrice.toLocaleString('fr-FR')} FCFA`;
  
  // wa.me links work universally, whether WhatsApp is open or closed
  return `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(message)}`;
}