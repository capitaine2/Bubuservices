import { RefObject } from 'react';

export function scrollToElement(elementRef: RefObject<HTMLElement>, offset = 0) {
  if (elementRef.current) {
    const elementPosition = elementRef.current.getBoundingClientRect().top;
    const offsetPosition = elementPosition + window.pageYOffset - offset;

    window.scrollTo({
      top: offsetPosition,
      behavior: 'smooth'
    });
  }
}