export const BUSINESS_HOURS = {
  start: 9,
  end: 22,
};

export function isBusinessDay(date: Date): boolean {
  const day = date.getDay();
  return day >= 1 && day <= 6;
}

export function isBusinessHour(hour: number): boolean {
  return hour >= BUSINESS_HOURS.start && hour < BUSINESS_HOURS.end;
}

export function isWithinLastWeek(date: Date): boolean {
  const now = new Date();
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  return date >= weekAgo && date <= now;
}

export function formatDate(date: Date): string {
  return date.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}