import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  condition: 'new' | 'refurbished';
  createdAt: Date;
  isPublished: boolean;
};

type ProductState = {
  products: Product[];
  addProduct: (product: Omit<Product, 'id' | 'createdAt' | 'isPublished'>) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  deleteProductByName: (name: string) => void;
  getProductsByCategory: (category: string) => Product[];
  getPublishedProducts: () => Product[];
};

export const useProductStore = create<ProductState>()(
  persist(
    (set, get) => ({
      products: [],
      addProduct: (product) => {
        const newProduct = {
          ...product,
          id: Math.random().toString(36).substr(2, 9),
          createdAt: new Date(),
          isPublished: true, // Auto-publish products when added
        };
        set((state) => ({
          products: [...state.products, newProduct],
        }));
      },
      updateProduct: (id, updates) => {
        set((state) => ({
          products: state.products.map((product) =>
            product.id === id ? { ...product, ...updates } : product
          ),
        }));
      },
      deleteProduct: (id) => {
        set((state) => ({
          products: state.products.filter((product) => product.id !== id),
        }));
      },
      deleteProductByName: (name) => {
        set((state) => ({
          products: state.products.filter((product) => product.name !== name),
        }));
      },
      getProductsByCategory: (category) => {
        return get().products.filter(
          (product) => product.category === category && product.isPublished
        );
      },
      getPublishedProducts: () => {
        return get().products.filter((product) => product.isPublished);
      },
    }),
    {
      name: 'product-storage',
    }
  )
);