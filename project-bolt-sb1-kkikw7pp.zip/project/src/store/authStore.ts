import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type AuthState = {
  isAdmin: boolean;
  login: (password: string) => boolean;
  logout: () => void;
};

const ADMIN_PASSWORD = 'Omzo1994@';

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      isAdmin: false,
      login: (password: string) => {
        const isValid = password === ADMIN_PASSWORD;
        if (isValid) {
          set({ isAdmin: true });
        }
        return isValid;
      },
      logout: () => set({ isAdmin: false }),
    }),
    {
      name: 'auth-storage',
    }
  )
);