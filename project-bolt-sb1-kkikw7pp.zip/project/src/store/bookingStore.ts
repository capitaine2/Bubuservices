import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { isWithinLastWeek } from '../utils/dateUtils';

export type Booking = {
  id: string;
  clientName: string;
  deviceType: string;
  date: string;
  time: string;
  description: string;
  isNew?: boolean;
  createdAt: Date;
};

type BookingState = {
  isFormOpen: boolean;
  selectedDeviceType: string;
  bookings: Booking[];
  unreadBookings: number;
  openBookingForm: (deviceType?: string) => void;
  closeBookingForm: () => void;
  addBooking: (booking: Omit<Booking, 'id' | 'isNew' | 'createdAt'>) => void;
  markBookingsAsRead: () => void;
  getActiveBookings: () => Booking[];
};

export const useBookingStore = create<BookingState>()(
  persist(
    (set, get) => ({
      isFormOpen: false,
      selectedDeviceType: '',
      bookings: [],
      unreadBookings: 0,
      openBookingForm: (deviceType = '') => 
        set({ isFormOpen: true, selectedDeviceType: deviceType }),
      closeBookingForm: () => 
        set({ isFormOpen: false, selectedDeviceType: '' }),
      addBooking: (booking) =>
        set((state) => ({
          bookings: [
            {
              ...booking,
              id: Math.random().toString(36).substr(2, 9),
              isNew: true,
              createdAt: new Date(),
            },
            ...state.bookings,
          ],
          unreadBookings: state.unreadBookings + 1,
        })),
      markBookingsAsRead: () =>
        set((state) => ({
          bookings: state.bookings.map(booking => ({ ...booking, isNew: false })),
          unreadBookings: 0,
        })),
      getActiveBookings: () => {
        return get().bookings.filter(booking => 
          isWithinLastWeek(new Date(booking.createdAt))
        );
      },
    }),
    {
      name: 'booking-storage',
    }
  )
);