import { create } from 'zustand';

type AdminView = 'products' | 'bookings';

type AdminState = {
  currentView: AdminView;
  setView: (view: AdminView) => void;
};

export const useAdminStore = create<AdminState>((set) => ({
  currentView: 'products',
  setView: (view) => set({ currentView: view }),
}));