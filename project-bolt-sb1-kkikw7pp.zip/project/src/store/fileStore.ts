import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type StoredFile = {
  id: string;
  title: string;
  description: string;
  price: number;
  imageData: string;
  uploadDate: Date;
};

type FileStore = {
  files: StoredFile[];
  addFile: (file: StoredFile) => void;
  removeFile: (id: string) => void;
  getFile: (id: string) => StoredFile | undefined;
};

export const useFileStore = create<FileStore>()(
  persist(
    (set, get) => ({
      files: [],
      addFile: (file) => {
        set((state) => ({
          files: [...state.files, file],
        }));
      },
      removeFile: (id) => {
        set((state) => ({
          files: state.files.filter((file) => file.id !== id),
        }));
      },
      getFile: (id) => {
        return get().files.find((file) => file.id === id);
      },
    }),
    {
      name: 'file-storage',
    }
  )
);