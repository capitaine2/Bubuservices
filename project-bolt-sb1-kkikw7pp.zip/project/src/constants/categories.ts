import { Smartphone, Laptop, Headphones, Gamepad, Monitor, Printer, Camera, Watch } from 'lucide-react';

export const PRODUCT_CATEGORIES = [
  { id: 'smartphones', label: 'Smartphones', icon: Smartphone },
  { id: 'laptops', label: 'Ordinateurs Portables', icon: Laptop },
  { id: 'monitors', label: 'Écrans', icon: Monitor },
  { id: 'printers', label: 'Imprimantes', icon: Printer },
  { id: 'cameras', label: 'Appareils Photo', icon: Camera },
  { id: 'accessories', label: 'Accessoires', icon: Headphones },
  { id: 'gaming', label: 'Gaming', icon: Gamepad },
  { id: 'wearables', label: 'Montres Connectées', icon: Watch },
] as const;

export type ProductCategory = typeof PRODUCT_CATEGORIES[number]['id'];