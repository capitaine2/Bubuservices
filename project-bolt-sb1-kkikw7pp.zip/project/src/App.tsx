import React, { useRef } from 'react';
import { Hero } from './components/sections/Hero';
import { Features } from './components/sections/Features';
import { ProductCatalog } from './components/products/ProductCatalog';
import { ChatProvider } from './components/chat/ChatProvider';
import { AdminFileManager } from './components/admin/AdminFileManager';
import { BookingForm } from './components/booking/BookingForm';
import { Toaster } from 'react-hot-toast';
import { Header } from './components/layout/Header';

function App() {
  const productsRef = useRef<HTMLElement>(null);

  return (
    <ChatProvider>
      <div className="min-h-screen pt-16">
        <Header />
        <Hero productsRef={productsRef} />
        <Features />
        <section ref={productsRef}>
          <ProductCatalog />
        </section>
        <BookingForm />
        <AdminFileManager />
        <Toaster position="top-right" />
      </div>
    </ChatProvider>
  );
}

export default App;