import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { File, Trash2, Download } from 'lucide-react';
import { formatFileSize } from '../../utils/fileUtils';

export type FileItem = {
  id: string;
  name: string;
  size: number;
  type: string;
  uploadDate: Date;
};

type FileListProps = {
  files: FileItem[];
  onDelete: (id: string) => void;
  onDownload: (id: string) => void;
};

export function FileList({ files, onDelete, onDownload }: FileListProps) {
  return (
    <div className="space-y-2">
      <AnimatePresence>
        {files.map((file) => (
          <motion.div
            key={file.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, x: -100 }}
            className="flex items-center justify-between p-4 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
          >
            <div className="flex items-center space-x-4">
              <File className="w-6 h-6 text-blue-500" />
              <div>
                <h4 className="font-medium text-gray-900">{file.name}</h4>
                <p className="text-sm text-gray-500">
                  {formatFileSize(file.size)} • {file.uploadDate.toLocaleDateString()}
                </p>
              </div>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => onDownload(file.id)}
                className="p-2 text-gray-600 hover:text-blue-600 rounded-full hover:bg-blue-50 transition-colors"
                title="Télécharger"
              >
                <Download className="w-5 h-5" />
              </button>
              <button
                onClick={() => onDelete(file.id)}
                className="p-2 text-gray-600 hover:text-red-600 rounded-full hover:bg-red-50 transition-colors"
                title="Supprimer"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}