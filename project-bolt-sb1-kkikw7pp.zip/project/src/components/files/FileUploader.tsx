import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion } from 'framer-motion';
import { Upload, File } from 'lucide-react';

type FileUploaderProps = {
  onFilesSelected: (files: File[]) => void;
  acceptedFileTypes?: string[];
};

export function FileUploader({ 
  onFilesSelected,
  acceptedFileTypes = ['.json']
}: FileUploaderProps) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    onFilesSelected(acceptedFiles);
  }, [onFilesSelected]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: acceptedFileTypes.reduce((acc, type) => ({
      ...acc,
      [type]: []
    }), {}),
    multiple: true
  });

  return (
    <motion.div
      {...getRootProps()}
      className={`p-8 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${
        isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400'
      }`}
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
    >
      <input {...getInputProps()} />
      <div className="flex flex-col items-center text-gray-600">
        <Upload className="w-12 h-12 mb-4 text-blue-500" />
        <p className="text-center mb-2">
          {isDragActive
            ? 'Déposez les fichiers ici...'
            : 'Glissez et déposez vos fichiers JSON ici, ou cliquez pour sélectionner'}
        </p>
        <p className="text-sm text-gray-500">
          Format accepté : JSON
        </p>
      </div>
    </motion.div>
  );
}