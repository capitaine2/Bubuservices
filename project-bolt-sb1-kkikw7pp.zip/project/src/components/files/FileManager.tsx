import React, { useState } from 'react';
import { FileUploader } from './FileUploader';
import { FileList, FileItem } from './FileList';
import { motion } from 'framer-motion';

export function FileManager() {
  const [files, setFiles] = useState<FileItem[]>([]);

  const handleFilesSelected = (selectedFiles: File[]) => {
    const newFiles: FileItem[] = selectedFiles.map((file) => ({
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
      type: file.type,
      uploadDate: new Date(),
    }));

    setFiles((prev) => [...prev, ...newFiles]);
  };

  const handleDelete = (id: string) => {
    setFiles((prev) => prev.filter((file) => file.id !== id));
  };

  const handleDownload = (id: string) => {
    const file = files.find((f) => f.id === id);
    if (file) {
      // In a real application, this would trigger the actual file download
      console.log(`Downloading file: ${file.name}`);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Gestionnaire de fichiers
          </h2>
          <FileUploader onFilesSelected={handleFilesSelected} />
        </div>

        {files.length > 0 && (
          <div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">
              Vos fichiers ({files.length})
            </h3>
            <FileList
              files={files}
              onDelete={handleDelete}
              onDownload={handleDownload}
            />
          </div>
        )}
      </motion.div>
    </div>
  );
}