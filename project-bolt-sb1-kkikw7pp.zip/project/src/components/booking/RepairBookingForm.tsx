import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Clock, Smartphone, Laptop, Tablet, Wrench, X } from 'lucide-react';
import { getAvailableTimeSlots, formatDate, isBusinessDay } from '../../utils/dateUtils';
import { useBookingStore } from '../../store/bookingStore';
import { toast } from 'react-hot-toast';

// ... (keep existing DEVICE_TYPES constant)

export function RepairBookingForm() {
  const { isFormOpen, selectedDeviceType, closeBookingForm, addBooking } = useBookingStore();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [deviceType, setDeviceType] = useState<string>(selectedDeviceType);
  const [description, setDescription] = useState<string>('');
  const [clientName, setClientName] = useState<string>('');

  useEffect(() => {
    setDeviceType(selectedDeviceType);
  }, [selectedDeviceType]);

  const availableTimeSlots = getAvailableTimeSlots(selectedDate);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!clientName || !selectedTime || !description) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    addBooking({
      clientName,
      deviceType,
      date: selectedDate.toISOString(),
      time: selectedTime,
      description,
    });

    toast.success('Réservation confirmée');
    closeBookingForm();
  };

  if (!isFormOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
    >
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.95 }}
        className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
      >
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Wrench className="w-6 h-6 text-blue-600" />
              <h2 className="text-2xl font-bold text-gray-900">
                Réserver une réparation
              </h2>
            </div>
            <button
              onClick={closeBookingForm}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-6 h-6 text-gray-500" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Client Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Votre nom
              </label>
              <input
                type="text"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="Entrez votre nom complet"
                required
              />
            </div>

            {/* Keep existing form fields (Device Type, Date, Time, Description) */}
            {/* ... */}

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
            >
              Confirmer la réservation
            </button>
          </form>
        </div>
      </motion.div>
    </motion.div>
  );
}