import React, { useState } from 'react';
import { Calendar, Clock } from 'lucide-react';
import { useBookingStore } from '../../store/bookingStore';
import { isBusinessDay, isBusinessHour } from '../../utils/dateUtils';
import { toast } from 'react-hot-toast';

type BookingFormFieldsProps = {
  onClose: () => void;
};

export function BookingFormFields({ onClose }: BookingFormFieldsProps) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedTime, setSelectedTime] = useState('');
  const addBooking = useBookingStore((state) => state.addBooking);

  const handleTimeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = e.target.value;
    const [hours] = time.split(':').map(Number);
    
    if (isBusinessHour(hours)) {
      setSelectedTime(time);
    } else {
      toast.error('Veuillez choisir une heure entre 9h et 22h');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!firstName || !lastName || !selectedTime) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    addBooking({
      clientName: `${firstName} ${lastName}`,
      deviceType: '',
      date: selectedDate.toISOString(),
      time: selectedTime,
      description: '',
    });

    toast.success('Réservation confirmée');
    onClose();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Prénom
          </label>
          <input
            type="text"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Votre prénom"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Nom
          </label>
          <input
            type="text"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Votre nom"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Date
        </label>
        <div className="relative">
          <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="date"
            value={selectedDate.toISOString().split('T')[0]}
            onChange={(e) => {
              const date = new Date(e.target.value);
              if (isBusinessDay(date)) {
                setSelectedDate(date);
                setSelectedTime('');
              } else {
                toast.error('Veuillez choisir un jour ouvré (Lundi à Samedi)');
              }
            }}
            className="w-full pl-10 p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Heure
        </label>
        <div className="relative">
          <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="time"
            value={selectedTime}
            onChange={handleTimeChange}
            min="09:00"
            max="22:00"
            step="1800"
            className="w-full pl-10 p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            required
          />
          <span className="text-xs text-gray-500 mt-1 block">
            Horaires d'ouverture : 9h - 22h
          </span>
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
      >
        Confirmer la réservation
      </button>
    </form>
  );
}