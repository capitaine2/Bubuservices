import React from 'react';
import { motion } from 'framer-motion';
import { Check, Calendar } from 'lucide-react';

type BookingConfirmationProps = {
  booking: {
    clientName: string;
    date: string;
    time: string;
  };
  onConfirm: () => void;
};

export function BookingConfirmation({ booking, onConfirm }: BookingConfirmationProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white p-6 rounded-lg shadow-lg"
    >
      <div className="text-center mb-6">
        <div className="mx-auto w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
          <Calendar className="w-6 h-6 text-green-600" />
        </div>
        <h3 className="text-xl font-semibold mb-2">Confirmez votre réservation</h3>
      </div>

      <div className="space-y-4 mb-6">
        <div className="bg-gray-50 p-4 rounded-lg">
          <p className="font-medium">Client: {booking.clientName}</p>
          <p>Date: {new Date(booking.date).toLocaleDateString('fr-FR')}</p>
          <p>Heure: {booking.time}</p>
        </div>
      </div>

      <button
        onClick={onConfirm}
        className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
      >
        <Check className="w-5 h-5" />
        Confirmer la réservation
      </button>
    </motion.div>
  );
}