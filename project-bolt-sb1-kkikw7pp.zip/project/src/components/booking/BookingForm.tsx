import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { useBookingStore } from '../../store/bookingStore';
import { BookingFormFields } from './BookingFormFields';

export function BookingForm() {
  const { isFormOpen, closeBookingForm } = useBookingStore();

  if (!isFormOpen) return null;

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      closeBookingForm();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
      onClick={handleBackdropClick}
    >
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.95 }}
        className="bg-white rounded-lg shadow-xl w-full max-w-md"
      >
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900">
              Réserver une réparation
            </h2>
            <button
              onClick={closeBookingForm}
              className="p-1 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          <BookingFormFields onClose={closeBookingForm} />
        </div>
      </motion.div>
    </motion.div>
  );
}