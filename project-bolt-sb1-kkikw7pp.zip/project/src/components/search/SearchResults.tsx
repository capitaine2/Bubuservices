import React from 'react';
import { motion } from 'framer-motion';
import { Product } from '../../store/productStore';

type SearchResultsProps = {
  products: Product[];
  onSelect: (productId: string) => void;
};

export function SearchResults({ products, onSelect }: SearchResultsProps) {
  if (products.length === 0) {
    return (
      <div className="p-4 text-center text-gray-500">
        Aucun résultat trouvé
      </div>
    );
  }

  return (
    <>
      {products.map((product) => (
        <motion.div
          key={product.id}
          className="flex items-center gap-4 p-4 hover:bg-gray-50 cursor-pointer"
          onClick={() => onSelect(product.id)}
          whileHover={{ x: 4 }}
        >
          <img
            src={product.imageUrl}
            alt={product.name}
            className="w-12 h-12 object-cover rounded"
          />
          <div>
            <h4 className="font-semibold">{product.name}</h4>
            <p className="text-sm text-gray-600">
              {product.price.toLocaleString('fr-FR')} FCFA
            </p>
          </div>
        </motion.div>
      ))}
    </>
  );
}