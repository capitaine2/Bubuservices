import React from 'react';
import { motion } from 'framer-motion';

type AnimatedTextProps = {
  children: React.ReactNode;
  delay?: number;
  className?: string;
  type?: 'heading' | 'paragraph';
};

export function AnimatedText({ children, delay = 0, className = '', type = 'paragraph' }: AnimatedTextProps) {
  const animations = {
    heading: {
      initial: { y: 20, opacity: 0 },
      animate: { y: 0, opacity: 1 },
      transition: { duration: 0.8, delay, ease: [0.33, 1, 0.68, 1] }
    },
    paragraph: {
      initial: { opacity: 0 },
      animate: { opacity: 1 },
      transition: { duration: 0.6, delay, ease: 'easeOut' }
    }
  };

  return (
    <motion.div
      className={className}
      {...animations[type]}
    >
      {children}
    </motion.div>
  );
}