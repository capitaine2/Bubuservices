import React from 'react';
import { motion } from 'framer-motion';

type AnimatedCardProps = {
  children: React.ReactNode;
  delay?: number;
};

export function AnimatedCard({ children, delay = 0 }: AnimatedCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ 
        duration: 0.6, 
        delay,
        ease: [0.25, 0.1, 0.25, 1]
      }}
      whileHover={{ 
        y: -5,
        transition: { duration: 0.2 }
      }}
      className="relative overflow-hidden rounded-xl bg-gradient-to-br from-white via-white to-gray-50 shadow-sm hover:shadow-md transition-shadow"
    >
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-transparent to-transparent"
        initial={{ x: '-100%' }}
        whileHover={{ x: '100%' }}
        transition={{ duration: 0.8 }}
      />
      {children}
    </motion.div>
  );
}