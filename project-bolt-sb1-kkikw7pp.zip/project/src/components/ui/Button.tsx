import React from 'react';
import { motion } from 'framer-motion';

type ButtonProps = {
  variant?: 'primary' | 'secondary';
  children: React.ReactNode;
  onClick?: () => void;
};

export function Button({ variant = 'primary', children, onClick }: ButtonProps) {
  const baseStyles = "relative px-6 py-3 rounded-lg font-semibold transition-all duration-200 overflow-hidden";
  const variants = {
    primary: "bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800",
    secondary: "bg-gradient-to-r from-gray-100 to-gray-200 text-gray-800 hover:from-gray-200 hover:to-gray-300"
  };

  return (
    <motion.button 
      className={`${baseStyles} ${variants[variant]}`}
      onClick={onClick}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-white/20 via-white/0 to-white/0"
        initial={{ x: '-100%' }}
        whileHover={{ x: '100%' }}
        transition={{ duration: 0.8 }}
      />
      {children}
    </motion.button>
  );
}