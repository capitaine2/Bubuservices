import React from 'react';
import { Wrench } from 'lucide-react';

export function Logo() {
  return (
    <div className="flex items-center gap-2">
      <Wrench className="h-8 w-8 text-blue-600" />
      <span className="text-xl font-bold text-gray-900">Bubu Services</span>
    </div>
  );
}