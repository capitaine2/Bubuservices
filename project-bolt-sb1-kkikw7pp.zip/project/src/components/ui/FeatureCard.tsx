import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';
import { AnimatedText } from './AnimatedText';
import { AnimatedCard } from './AnimatedCard';

type FeatureCardProps = {
  icon: LucideIcon;
  title: string;
  description: string;
  delay?: number;
};

export function FeatureCard({ icon: Icon, title, description, delay = 0 }: FeatureCardProps) {
  return (
    <AnimatedCard delay={delay}>
      <div className="p-6">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          whileInView={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, delay: delay + 0.2 }}
        >
          <Icon className="w-12 h-12 text-blue-600 mb-4" />
        </motion.div>
        <AnimatedText type="heading" delay={delay + 0.3} className="text-xl font-semibold mb-2">
          {title}
        </AnimatedText>
        <AnimatedText delay={delay + 0.4} className="text-gray-600">
          {description}
        </AnimatedText>
      </div>
    </AnimatedCard>
  );
}