import React from 'react';
import { motion } from 'framer-motion';

type GradientBackgroundProps = {
  children: React.ReactNode;
  imageUrl: string;
};

export function GradientBackground({ children, imageUrl }: GradientBackgroundProps) {
  return (
    <div className="relative">
      <motion.div 
        className="absolute inset-0 z-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5 }}
        style={{
          backgroundImage: `url("${imageUrl}")`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <motion.div 
          className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/60 to-black/50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 2, delay: 0.5 }}
        />
      </motion.div>
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}