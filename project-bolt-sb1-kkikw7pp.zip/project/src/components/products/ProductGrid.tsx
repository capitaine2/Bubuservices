import React from 'react';
import { ProductCard } from './ProductCard';
import { useProductStore } from '../../store/productStore';

type ProductGridProps = {
  category?: string;
};

export function ProductGrid({ category }: ProductGridProps) {
  const products = useProductStore(
    (state) => category 
      ? state.getProductsByCategory(category)
      : state.getPublishedProducts()
  );

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600">
          Aucun produit disponible dans cette catégorie pour le moment.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}