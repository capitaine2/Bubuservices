import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Smartphone, Laptop, Headphones, Gamepad } from 'lucide-react';
import { ProductGrid } from './ProductGrid';

export const CATEGORIES = [
  { id: 'smartphones', label: 'Smartphones', icon: Smartphone },
  { id: 'laptops', label: 'Ordinateurs', icon: Laptop },
  { id: 'accessories', label: 'Accessoires', icon: Headphones },
  { id: 'gaming', label: 'Gaming', icon: Gamepad },
];

export function ProductCatalog() {
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section id="products-section" className="py-12">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: isVisible ? 1 : 0, y: isVisible ? 0 : 20 }}
          className="space-y-8"
        >
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Nos Produits
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Découvrez notre sélection de produits neufs et reconditionnés,
              soigneusement choisis pour répondre à vos besoins.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4">
            <motion.button
              onClick={() => setSelectedCategory('')}
              className={`px-6 py-3 rounded-lg transition-colors ${
                selectedCategory === ''
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Tout
            </motion.button>
            {CATEGORIES.map(({ id, label, icon: Icon }) => (
              <motion.button
                key={id}
                onClick={() => setSelectedCategory(id)}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-colors ${
                  selectedCategory === id
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Icon className="w-5 h-5" />
                {label}
              </motion.button>
            ))}
          </div>

          {/* Product Grid */}
          <ProductGrid category={selectedCategory} />
        </motion.div>
      </div>
    </section>
  );
}