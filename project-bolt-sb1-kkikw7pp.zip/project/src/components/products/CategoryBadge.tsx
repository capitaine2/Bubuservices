import React from 'react';
import { PRODUCT_CATEGORIES } from '../../constants/categories';

type CategoryBadgeProps = {
  categoryId: string;
};

export function CategoryBadge({ categoryId }: CategoryBadgeProps) {
  const category = PRODUCT_CATEGORIES.find(cat => cat.id === categoryId);
  
  if (!category) return null;
  
  const Icon = category.icon;
  
  return (
    <div className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
      <Icon className="w-4 h-4" />
      <span>{category.label}</span>
    </div>
  );
}