import React from 'react';
import { ShoppingBag } from 'lucide-react';
import { useCartStore } from '../../store/cartStore';
import { generateWhatsAppOrderUrl } from '../../utils/whatsAppUtils';

export function CartSummary() {
  const { items, getTotalPrice } = useCartStore();

  return (
    <div className="border-t pt-4">
      <div className="flex justify-between items-center mb-4">
        <span className="font-semibold">Total</span>
        <span className="font-bold text-xl">
          {getTotalPrice().toLocaleString('fr-FR')} FCFA
        </span>
      </div>
      <a 
        href={generateWhatsAppOrderUrl(items, getTotalPrice())}
        target="_blank"
        rel="noopener noreferrer"
        className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
      >
        <ShoppingBag className="w-5 h-5" />
        Commander via WhatsApp
      </a>
    </div>
  );
}