import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '../ui/Button';
import { AnimatedText } from '../ui/AnimatedText';
import { GradientBackground } from '../ui/GradientBackground';
import { useBookingStore } from '../../store/bookingStore';
import { scrollToElement } from '../../utils/scrollUtils';

type HeroProps = {
  productsRef: React.RefObject<HTMLElement>;
};

export function Hero({ productsRef }: HeroProps) {
  const openBookingForm = useBookingStore((state) => state.openBookingForm);

  const handleProductsClick = () => {
    // Add a small offset to account for any fixed headers
    scrollToElement(productsRef, 80);
  };

  return (
    <GradientBackground 
      imageUrl="https://images.unsplash.com/photo-1581092921461-eab62e97a780?auto=format&fit=crop&q=80"
    >
      <div className="h-[600px] flex items-center">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl text-white">
            <AnimatedText type="heading" className="text-5xl font-bold mb-6">
              Bubu Services : Experts en Technologie et Réparation
            </AnimatedText>
            
            <AnimatedText delay={0.2} className="text-xl mb-8 text-gray-200">
              Vente de produits technologiques de pointe et réparations rapides et garanties.
            </AnimatedText>

            <motion.div 
              className="flex gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Button 
                variant="primary"
                onClick={handleProductsClick}
              >
                Voir nos produits
              </Button>
              <Button 
                variant="secondary"
                onClick={() => openBookingForm()}
              >
                Réservez une réparation
              </Button>
            </motion.div>
          </div>
        </div>
      </div>
    </GradientBackground>
  );
}