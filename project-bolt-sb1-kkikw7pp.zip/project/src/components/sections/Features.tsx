import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Shield, Award, Smartphone } from 'lucide-react';
import { FeatureCard } from '../ui/FeatureCard';
import { AnimatedText } from '../ui/AnimatedText';

export function Features() {
  const features = [
    {
      icon: Clock,
      title: "Réparations en 24h",
      description: "Service rapide et efficace pour minimiser votre temps d'attente"
    },
    {
      icon: Shield,
      title: "Garantie jusqu'à 12 mois",
      description: "Tranquillité d'esprit avec notre garantie sur les réparations"
    },
    {
      icon: Award,
      title: "Experts certifiés",
      description: "Une équipe de professionnels qualifiés à votre service"
    },
    {
      icon: Smartphone,
      title: "Produits neufs et reconditionnés",
      description: "Large gamme d'appareils pour tous les budgets"
    }
  ];

  return (
    <section className="py-20">
      <motion.div 
        className="container mx-auto px-4"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        <AnimatedText type="heading" className="text-3xl font-bold text-center mb-12">
          Pourquoi nous choisir ?
        </AnimatedText>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <FeatureCard 
              key={index} 
              {...feature} 
              delay={index * 0.1}
            />
          ))}
        </div>
      </motion.div>
    </section>
  );
}