import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, AlertCircle } from 'lucide-react';
import { useFileStore, StoredFile } from '../../store/fileStore';

export function FileImportForm() {
  const [error, setError] = useState<string>('');
  const addFile = useFileStore((state) => state.addFile);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    try {
      for (const file of Array.from(files)) {
        const reader = new FileReader();
        
        reader.onload = async (e) => {
          const base64Data = e.target?.result as string;
          
          const storedFile: StoredFile = {
            id: Math.random().toString(36).substring(2, 9),
            name: file.name,
            size: file.size,
            type: file.type,
            lastModified: file.lastModified,
            uploadDate: new Date(),
            data: base64Data.split(',')[1], // Remove data URL prefix
          };

          addFile(storedFile);
        };

        reader.onerror = () => {
          setError('Une erreur est survenue lors de la lecture du fichier.');
        };

        reader.readAsDataURL(file);
      }

      // Reset the input
      event.target.value = '';
      setError('');
    } catch (err) {
      setError('Une erreur est survenue lors de l\'importation des fichiers.');
      console.error('Error importing files:', err);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h3 className="text-lg font-semibold mb-4">Importer des fichiers</h3>
      
      <div className="space-y-4">
        <div className="relative">
          <input
            type="file"
            onChange={handleFileChange}
            className="hidden"
            id="file-upload"
            multiple
            accept=".json,.pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
          />
          
          <label
            htmlFor="file-upload"
            className="flex flex-col items-center justify-center w-full p-6 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-blue-400 transition-colors"
          >
            <Upload className="w-12 h-12 text-blue-500 mb-2" />
            <span className="text-sm text-gray-600">
              Cliquez pour sélectionner des fichiers
            </span>
            <span className="text-xs text-gray-500 mt-1">
              Formats acceptés: JSON, PDF, DOC, XLSX, Images
            </span>
          </label>
        </div>

        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 bg-red-50 text-red-600 rounded-lg flex items-center gap-2"
          >
            <AlertCircle className="w-5 h-5" />
            <p className="text-sm">{error}</p>
          </motion.div>
        )}
      </div>
    </div>
  );
}