import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, AlertCircle } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { useFileStore, StoredFile } from '../../store/fileStore';
import { FileList } from './FileList';
import { CategorySelect } from './CategorySelect';

export function ProductManager() {
  const [error, setError] = useState<string>('');
  const [productInfo, setProductInfo] = useState({
    title: '',
    description: '',
    price: '',
    category: '',
  });
  const addFile = useFileStore((state) => state.addFile);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProductInfo(prev => ({ ...prev, [name]: value }));
  };

  const onDrop = async (acceptedFiles: File[]) => {
    if (!productInfo.title || !productInfo.description || !productInfo.price || !productInfo.category) {
      setError('Veuillez remplir tous les champs avant d\'ajouter une image');
      return;
    }

    try {
      const file = acceptedFiles[0];
      const reader = new FileReader();
      
      reader.onload = async (e) => {
        const base64Data = e.target?.result as string;
        
        const storedFile: StoredFile = {
          id: Math.random().toString(36).substring(2, 9),
          title: productInfo.title,
          description: productInfo.description,
          price: parseFloat(productInfo.price) || 0,
          category: productInfo.category,
          imageData: base64Data,
          uploadDate: new Date(),
        };

        addFile(storedFile);
        setProductInfo({
          title: '',
          description: '',
          price: '',
          category: '',
        });
      };

      reader.onerror = () => {
        setError('Une erreur est survenue lors de la lecture du fichier.');
      };

      reader.readAsDataURL(file);
      setError('');
    } catch (err) {
      setError('Erreur lors de l\'importation. Vérifiez le format des fichiers.');
      console.error('Error importing files:', err);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpg', '.jpeg', '.png'],
    },
    maxFiles: 1,
  });

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="text-lg font-semibold mb-4">Ajouter un nouveau produit</h3>
        
        <div className="space-y-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Titre du produit
            </label>
            <input
              type="text"
              name="title"
              value={productInfo.title}
              onChange={handleInputChange}
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="Ex: iPhone 13 Pro Max - 256GB"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Description
            </label>
            <textarea
              name="description"
              value={productInfo.description}
              onChange={handleInputChange}
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              rows={3}
              placeholder="Décrivez les caractéristiques principales du produit..."
              required
            />
          </div>

          <CategorySelect
            value={productInfo.category}
            onChange={(category) => setProductInfo(prev => ({ ...prev, category }))}
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Prix (FCFA)
            </label>
            <input
              type="number"
              name="price"
              value={productInfo.price}
              onChange={handleInputChange}
              className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="150000"
              required
            />
          </div>
        </div>
        
        <div {...getRootProps()} className="space-y-4">
          <input {...getInputProps()} />
          
          <div className={`p-8 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${
            isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400'
          }`}>
            <div className="flex flex-col items-center text-gray-600">
              <Upload className="w-12 h-12 mb-4 text-blue-500" />
              <p className="text-center mb-2">
                {isDragActive
                  ? 'Déposez l\'image ici...'
                  : 'Glissez et déposez l\'image du produit ici, ou cliquez pour sélectionner'}
              </p>
            </div>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 bg-red-50 text-red-600 rounded-lg flex items-center gap-2"
            >
              <AlertCircle className="w-5 h-5" />
              <p className="text-sm">{error}</p>
            </motion.div>
          )}
        </div>
      </div>

      <FileList />
    </div>
  );
}