import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, Trash2, Share2 } from 'lucide-react';
import { useFileStore, StoredFile } from '../../store/fileStore';
import { useProductStore } from '../../store/productStore';
import { toast } from 'react-hot-toast';

export function FileList() {
  const { files, removeFile } = useFileStore();
  const { addProduct, products, deleteProductByName } = useProductStore();

  const handleDownload = (file: StoredFile) => {
    const a = document.createElement('a');
    a.href = file.imageData;
    a.download = `${file.title}.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDelete = (file: StoredFile) => {
    // Remove from FileStore
    removeFile(file.id);
    
    // Remove from ProductStore if published
    deleteProductByName(file.title);
    
    toast.success('Produit supprimé avec succès');
  };

  const handlePublish = (file: StoredFile) => {
    // Check if product already exists
    const isAlreadyPublished = products.some(
      (product) => product.name === file.title && product.isPublished
    );

    if (isAlreadyPublished) {
      toast.error('Ce produit est déjà publié');
      return;
    }

    addProduct({
      name: file.title,
      description: file.description,
      price: file.price,
      imageUrl: file.imageData,
      category: 'smartphones',
      condition: 'new',
    });

    toast.success('Produit publié avec succès');
    
    // Scroll to products section
    const productsSection = document.getElementById('products-section');
    if (productsSection) {
      productsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  if (files.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        Aucun produit importé
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Produits importés</h3>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <AnimatePresence>
          {files.map((file) => (
            <motion.div
              key={file.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: -100 }}
              className="bg-white rounded-lg shadow-sm overflow-hidden"
            >
              <div className="aspect-video relative overflow-hidden bg-gray-100">
                <img
                  src={file.imageData}
                  alt={file.title}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="p-4">
                <h4 className="font-semibold text-lg mb-2">{file.title}</h4>
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                  {file.description}
                </p>
                
                <div className="flex items-center justify-between mb-4">
                  <span className="text-lg font-bold text-gray-900">
                    {file.price.toLocaleString('fr-FR')} FCFA
                  </span>
                  <span className="text-sm text-gray-500">
                    {new Date(file.uploadDate).toLocaleDateString()}
                  </span>
                </div>

                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => handlePublish(file)}
                    className="p-2 text-gray-600 hover:text-green-600 rounded-full hover:bg-green-50 transition-colors group relative"
                    title="Publier"
                  >
                    <Share2 className="w-5 h-5" />
                    <span className="absolute -top-8 right-0 bg-gray-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                      Publier sur la boutique
                    </span>
                  </button>
                  <button
                    onClick={() => handleDownload(file)}
                    className="p-2 text-gray-600 hover:text-blue-600 rounded-full hover:bg-blue-50 transition-colors"
                    title="Télécharger"
                  >
                    <Download className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDelete(file)}
                    className="p-2 text-gray-600 hover:text-red-600 rounded-full hover:bg-red-50 transition-colors"
                    title="Supprimer"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}