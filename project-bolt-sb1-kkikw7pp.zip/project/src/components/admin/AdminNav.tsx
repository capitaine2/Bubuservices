import React from 'react';
import { Package, Calendar, LogOut } from 'lucide-react';
import { useAdminStore } from '../../store/adminStore';
import { useAuthStore } from '../../store/authStore';
import { useBookingStore } from '../../store/bookingStore';

export function AdminNav() {
  const { currentView, setView } = useAdminStore();
  const logout = useAuthStore((state) => state.logout);
  const unreadBookings = useBookingStore((state) => state.unreadBookings);

  const navItems = [
    { id: 'products', label: 'Produits', icon: Package },
    { 
      id: 'bookings', 
      label: 'Réservations', 
      icon: Calendar,
      notification: unreadBookings 
    },
  ];

  return (
    <nav className="w-64 min-h-screen bg-white border-r border-gray-200 p-4">
      <div className="flex flex-col h-full">
        <div className="space-y-1">
          {navItems.map(({ id, label, icon: Icon, notification }) => (
            <button
              key={id}
              onClick={() => setView(id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                currentView === id
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{label}</span>
              {notification > 0 && (
                <span className="ml-auto bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  {notification}
                </span>
              )}
            </button>
          ))}
        </div>

        <button
          onClick={logout}
          className="mt-auto flex items-center gap-3 px-4 py-3 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
        >
          <LogOut className="w-5 h-5" />
          Déconnexion
        </button>
      </div>
    </nav>
  );
}