import React from 'react';
import { AdminNav } from './AdminNav';
import { ProductManager } from './ProductManager';
import { BookingManager } from './BookingManager';
import { useAdminStore } from '../../store/adminStore';

export function Dashboard() {
  const { currentView } = useAdminStore();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        <AdminNav />
        <main className="flex-1 p-8">
          <div className="max-w-7xl mx-auto space-y-8">
            {currentView === 'products' && <ProductManager />}
            {currentView === 'bookings' && <BookingManager />}
          </div>
        </main>
      </div>
    </div>
  );
}