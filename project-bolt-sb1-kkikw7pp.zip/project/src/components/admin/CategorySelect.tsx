import React from 'react';
import { PRODUCT_CATEGORIES } from '../../constants/categories';

type CategorySelectProps = {
  value: string;
  onChange: (category: string) => void;
};

export function CategorySelect({ value, onChange }: CategorySelectProps) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        Catégorie
      </label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full p-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
        required
      >
        <option value="">Sélectionnez une catégorie</option>
        {PRODUCT_CATEGORIES.map(({ id, label }) => (
          <option key={id} value={id}>
            {label}
          </option>
        ))}
      </select>
    </div>
  );
}