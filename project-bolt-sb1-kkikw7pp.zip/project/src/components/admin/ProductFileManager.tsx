import React, { useState } from 'react';
import { FileUploader } from '../files/FileUploader';
import { FileList, FileItem } from '../files/FileList';
import { motion } from 'framer-motion';
import { useAuthStore } from '../../store/authStore';
import { LogOut } from 'lucide-react';

export function ProductFileManager() {
  const [files, setFiles] = useState<FileItem[]>([]);
  const logout = useAuthStore((state) => state.logout);

  const handleFilesSelected = (selectedFiles: File[]) => {
    const newFiles: FileItem[] = selectedFiles.map((file) => ({
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
      type: file.type,
      uploadDate: new Date(),
    }));

    setFiles((prev) => [...prev, ...newFiles]);
  };

  const handleDelete = (id: string) => {
    setFiles((prev) => prev.filter((file) => file.id !== id));
  };

  const handleDownload = (id: string) => {
    const file = files.find((f) => f.id === id);
    if (file) {
      console.log(`Downloading file: ${file.name}`);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-gray-900">
            Gestion des produits
          </h2>
          <button
            onClick={logout}
            className="flex items-center gap-2 px-4 py-2 text-sm text-gray-600 hover:text-gray-900"
          >
            <LogOut className="w-4 h-4" />
            Déconnexion
          </button>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-lg font-semibold mb-4">Ajouter des produits</h3>
          <FileUploader onFilesSelected={handleFilesSelected} />
          
          <div className="mt-6">
            <p className="text-sm text-gray-600 mb-2">Formats acceptés :</p>
            <ul className="text-sm text-gray-600 list-disc list-inside">
              <li>Images produits (JPG, PNG)</li>
              <li>Fiches produits (PDF)</li>
              <li>Catalogues (PDF, XLSX)</li>
            </ul>
          </div>
        </div>

        {files.length > 0 && (
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h3 className="text-lg font-semibold mb-4">
              Fichiers produits ({files.length})
            </h3>
            <FileList
              files={files}
              onDelete={handleDelete}
              onDownload={handleDownload}
            />
          </div>
        )}
      </motion.div>
    </div>
  );
}