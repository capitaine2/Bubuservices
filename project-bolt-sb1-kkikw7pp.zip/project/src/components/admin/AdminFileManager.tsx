import React from 'react';
import { useAuthStore } from '../../store/authStore';
import { AdminLogin } from './AdminLogin';
import { Dashboard } from './Dashboard';

export function AdminFileManager() {
  const isAdmin = useAuthStore((state) => state.isAdmin);

  return isAdmin ? <Dashboard /> : <AdminLogin />;
}