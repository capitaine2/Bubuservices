import React, { useState } from 'react';
import { CartButton } from '../cart/CartButton';
import { CartDrawer } from '../cart/CartDrawer';
import { Logo } from '../ui/Logo';

export function Header() {
  const [isCartOpen, setIsCartOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md z-50 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="h-16 flex items-center justify-between">
          <Logo />
          <CartButton onClick={() => setIsCartOpen(true)} />
        </div>
      </div>
      <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </header>
  );
}